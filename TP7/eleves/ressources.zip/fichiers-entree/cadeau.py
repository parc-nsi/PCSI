# -*- coding: utf-8 -*-

import random
from math import sqrt


mon_fichier = open('tagada.txt','r')
s = 0
for L in mon_fichier:
    s += len(L)
mon_fichier.close()




def est_premier(n):
    if n <= 1:
        return False
    for k in range(2, 1+int(sqrt(n))):
        if n%k == 0:
            return False
    return True




def creer_departements(fichier, n):
    """Cree un fichier texte contenant n noms de départements
    de format *****numero_ligne où * est une lettre majuscule"""
    debut = ord('A')
    fin = ord('Z')
    f = open(fichier, 'w')
    for k in range(1, n+1):
        f.write(''.join(chr(random.randint(debut, fin)) for j in range(5)) + \
        str(k) + '\n')
    f.close()
    
def chrono(fonction):
    
    import time
    
    def fonction2(*args):
        chrono_debut = time.time()
        rep = fonction(*args)
        chrono_fin = time.time()
        print('Valeur de retour de {:s} : {:d} en {:1.6f} secondes'.format(\
        fonction.__name__, rep, chrono_fin - chrono_debut))
        
    return fonction2